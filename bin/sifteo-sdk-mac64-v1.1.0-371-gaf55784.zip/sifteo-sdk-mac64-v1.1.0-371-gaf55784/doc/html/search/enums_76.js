var searchData=
[
  ['videomode',['VideoMode',['../group__video.html#ga2e2ba8d4e602cffb8a6e9fc283b18b2f',1,'Sifteo']]]
];
