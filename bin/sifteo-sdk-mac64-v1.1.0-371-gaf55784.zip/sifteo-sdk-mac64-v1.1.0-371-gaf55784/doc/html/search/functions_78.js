var searchData=
[
  ['x',['x',['../struct_sifteo_1_1_sprite_ref.html#a8cf628cb56a69225c2d92f69fce316e6',1,'Sifteo::SpriteRef']]],
  ['xorb',['xorb',['../struct_sifteo_1_1_video_buffer.html#ab3c23e1d8eefdde108d281ec19aebfe3',1,'Sifteo::VideoBuffer']]],
  ['xy',['xy',['../struct_sifteo_1_1_vector3.html#af695f5b514c69a24edb57151a31c5210',1,'Sifteo::Vector3']]],
  ['xz',['xz',['../struct_sifteo_1_1_vector3.html#a9b44529f8114b80fb06361c61af5cbff',1,'Sifteo::Vector3']]]
];
