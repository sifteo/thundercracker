var searchData=
[
  ['neighboradd',['neighborAdd',['../namespace_sifteo_1_1_events.html#ad6b2eed71961c5d7702352666840b647',1,'Sifteo::Events']]],
  ['neighborremove',['neighborRemove',['../namespace_sifteo_1_1_events.html#a044cb196d5ccceee3c2834b8cf5e5dc7',1,'Sifteo::Events']]],
  ['num_5fchannels',['NUM_CHANNELS',['../struct_sifteo_1_1_audio_channel.html#a4289072f1db515238941dc84099a7de8',1,'Sifteo::AudioChannel']]],
  ['num_5fcolors',['NUM_COLORS',['../struct_sifteo_1_1_colormap.html#afafcb0570a05cffb1d6bb332fc486830',1,'Sifteo::Colormap']]],
  ['num_5fslots',['NUM_SLOTS',['../struct_sifteo_1_1_cube_i_d.html#ab51906ee1440e3a3605ab6e2a6464bb2',1,'Sifteo::CubeID']]]
];
