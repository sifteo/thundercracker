var searchData=
[
  ['powerdown_5fmode',['POWERDOWN_MODE',['../group__video.html#gga2e2ba8d4e602cffb8a6e9fc283b18b2fa56e1a5d40bf2d298e517b42de823b475',1,'Sifteo']]]
];
