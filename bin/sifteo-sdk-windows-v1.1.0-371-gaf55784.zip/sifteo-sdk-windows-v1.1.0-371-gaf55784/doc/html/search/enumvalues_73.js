var searchData=
[
  ['shake_5fbegin',['Shake_Begin',['../class_sifteo_1_1_tilt_shake_recognizer.html#a01fb99fdb0c94ff50953a0c9c2a75eb4a84dc84f307ac2347279ed05a6f7b3c19',1,'Sifteo::TiltShakeRecognizer']]],
  ['shake_5fchange',['Shake_Change',['../class_sifteo_1_1_tilt_shake_recognizer.html#a01fb99fdb0c94ff50953a0c9c2a75eb4a9f72907f11222345f22c0f8f307c7026',1,'Sifteo::TiltShakeRecognizer']]],
  ['shake_5fend',['Shake_End',['../class_sifteo_1_1_tilt_shake_recognizer.html#a01fb99fdb0c94ff50953a0c9c2a75eb4af7409a54c99a9bf56bf6b2d9f851f267',1,'Sifteo::TiltShakeRecognizer']]],
  ['solid_5fbg',['SOLID_BG',['../struct_sifteo_1_1_b_g0_r_o_m_drawable.html#abfd9db57c562b2e8056ad70ff03468efa884b5cad289e4e65e94ea3d6c076564f',1,'Sifteo::BG0ROMDrawable']]],
  ['solid_5ffg',['SOLID_FG',['../struct_sifteo_1_1_b_g0_r_o_m_drawable.html#abfd9db57c562b2e8056ad70ff03468efa77a182f493e1a37e27494dce9b016df1',1,'Sifteo::BG0ROMDrawable']]],
  ['solid_5fmode',['SOLID_MODE',['../group__video.html#gga2e2ba8d4e602cffb8a6e9fc283b18b2faf6683589ce73a10099bb49fe05c7ee52',1,'Sifteo']]],
  ['stamp',['STAMP',['../group__video.html#gga2e2ba8d4e602cffb8a6e9fc283b18b2fac58aef3d925f559c52c260b58ef062a0',1,'Sifteo']]]
];
