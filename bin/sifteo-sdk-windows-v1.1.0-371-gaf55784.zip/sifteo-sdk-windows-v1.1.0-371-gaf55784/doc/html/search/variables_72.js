var searchData=
[
  ['receivequeue',['receiveQueue',['../struct_sifteo_1_1_bluetooth_pipe.html#a9d28343e527dee9389ffbc9b583cb43a',1,'Sifteo::BluetoothPipe::receiveQueue()'],['../struct_sifteo_1_1_usb_pipe.html#a81f5d0c8744c9e84163fb0c86cfe1e7c',1,'Sifteo::UsbPipe::receiveQueue()']]]
];
