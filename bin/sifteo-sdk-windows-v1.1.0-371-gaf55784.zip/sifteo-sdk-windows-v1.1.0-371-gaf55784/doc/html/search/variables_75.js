var searchData=
[
  ['undefined',['UNDEFINED',['../struct_sifteo_1_1_audio_channel.html#add25e560eadc585a0cb132025a08e1d7',1,'Sifteo::AudioChannel::UNDEFINED()'],['../struct_sifteo_1_1_cube_i_d.html#ac9ab1ce1985b9cc8adf58912ce805fce',1,'Sifteo::CubeID::UNDEFINED()']]],
  ['usbconnect',['usbConnect',['../namespace_sifteo_1_1_events.html#ae279625c90783d4dc62a7fd7d728cb9d',1,'Sifteo::Events']]],
  ['usbdisconnect',['usbDisconnect',['../namespace_sifteo_1_1_events.html#a552ed151c3796398ec81cfe0ced1d874',1,'Sifteo::Events']]],
  ['usbreadavailable',['usbReadAvailable',['../namespace_sifteo_1_1_events.html#ab05389c2c9dab31f3e4c264096a0a32a',1,'Sifteo::Events']]],
  ['usbwriteavailable',['usbWriteAvailable',['../namespace_sifteo_1_1_events.html#a7bdbba07cc817471aaa855cd0f33cdb2',1,'Sifteo::Events']]]
];
