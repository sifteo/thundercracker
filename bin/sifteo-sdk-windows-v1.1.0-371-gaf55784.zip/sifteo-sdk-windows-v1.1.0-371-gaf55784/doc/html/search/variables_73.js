var searchData=
[
  ['sendqueue',['sendQueue',['../struct_sifteo_1_1_bluetooth_pipe.html#af85035470702be571d220950ab0716ce',1,'Sifteo::BluetoothPipe::sendQueue()'],['../struct_sifteo_1_1_usb_pipe.html#a2e78608490315ad0dc5bc524ae324cc3',1,'Sifteo::UsbPipe::sendQueue()']]],
  ['shake',['shake',['../class_sifteo_1_1_tilt_shake_recognizer.html#ac0f44403a7a8552e9f8e81a8b34b07c2',1,'Sifteo::TiltShakeRecognizer']]],
  ['sprites',['sprites',['../struct_sifteo_1_1_video_buffer.html#a8d31ae2f17dfdd8d63608ea9dff5b3aa',1,'Sifteo::VideoBuffer']]],
  ['stamp',['stamp',['../struct_sifteo_1_1_video_buffer.html#a499b8a9632dfe8bbfc7cb5ce5389a3c8',1,'Sifteo::VideoBuffer']]]
];
