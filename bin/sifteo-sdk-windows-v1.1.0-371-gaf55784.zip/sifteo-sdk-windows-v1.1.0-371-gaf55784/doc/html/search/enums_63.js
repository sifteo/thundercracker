var searchData=
[
  ['changeflags',['ChangeFlags',['../class_sifteo_1_1_tilt_shake_recognizer.html#a01fb99fdb0c94ff50953a0c9c2a75eb4',1,'Sifteo::TiltShakeRecognizer']]],
  ['colormode',['ColorMode',['../struct_sifteo_1_1_b_g0_r_o_m_drawable.html#a1654819d4b26ba0733269c49e9d1c123',1,'Sifteo::BG0ROMDrawable']]]
];
