var searchData=
[
  ['loopmode',['LoopMode',['../struct_sifteo_1_1_audio_channel.html#a2dccc94619b8f5f1aa1ee76868a788a0',1,'Sifteo::AudioChannel']]]
];
