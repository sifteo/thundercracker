var searchData=
[
  ['keepawake',['keepAwake',['../class_sifteo_1_1_system.html#a7316e95e241754c58f55c761dbd3c1d1',1,'Sifteo::System']]]
];
