var searchData=
[
  ['short2',['Short2',['../group__math.html#ga4b7628e29e2b48dca071eeb4dc426852',1,'Sifteo']]],
  ['short3',['Short3',['../group__math.html#gae7f0a2eaa3374dd2b52d2d10d3a123e4',1,'Sifteo']]]
];
