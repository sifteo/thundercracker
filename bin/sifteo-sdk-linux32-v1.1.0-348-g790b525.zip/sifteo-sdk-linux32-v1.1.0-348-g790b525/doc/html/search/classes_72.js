var searchData=
[
  ['random',['Random',['../struct_sifteo_1_1_random.html',1,'Sifteo']]],
  ['relocatabletilebuffer',['RelocatableTileBuffer',['../struct_sifteo_1_1_relocatable_tile_buffer.html',1,'Sifteo']]],
  ['rgb565',['RGB565',['../struct_sifteo_1_1_r_g_b565.html',1,'Sifteo']]]
];
