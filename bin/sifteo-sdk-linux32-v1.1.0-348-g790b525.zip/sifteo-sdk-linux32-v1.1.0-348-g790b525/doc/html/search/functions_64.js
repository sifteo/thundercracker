var searchData=
[
  ['delta',['delta',['../class_sifteo_1_1_time_step.html#ad76c63357ff9e11ded68593a68349ab9',1,'Sifteo::TimeStep']]],
  ['detach',['detach',['../struct_sifteo_1_1_bluetooth_pipe.html#a435d35a792875675a8de218c4e9c7028',1,'Sifteo::BluetoothPipe']]],
  ['detachmotionbuffer',['detachMotionBuffer',['../struct_sifteo_1_1_cube_i_d.html#afe9084daa9d9609cae70bed558e1f3cd',1,'Sifteo::CubeID']]],
  ['detachvideobuffer',['detachVideoBuffer',['../struct_sifteo_1_1_cube_i_d.html#a69ef118d050558bb080467b95f0fc865',1,'Sifteo::CubeID']]],
  ['disablekey',['disableKey',['../struct_sifteo_1_1_stamp_drawable.html#a1220be1ddf4a4864af99b76c415178c6',1,'Sifteo::StampDrawable']]],
  ['dot',['dot',['../group__math.html#gaed7c12b9ab92540d789a1a4322bafff3',1,'Sifteo::dot(Vector2&lt; T &gt; u, Vector2&lt; T &gt; v)'],['../group__math.html#ga40f30e4e24c977d91d95d42eb76889f8',1,'Sifteo::dot(Vector3&lt; T &gt; u, Vector3&lt; T &gt; v)']]]
];
