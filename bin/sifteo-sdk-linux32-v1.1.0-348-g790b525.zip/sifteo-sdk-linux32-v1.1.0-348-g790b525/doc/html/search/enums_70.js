var searchData=
[
  ['palette',['Palette',['../struct_sifteo_1_1_b_g0_r_o_m_drawable.html#ada13ca0ac5108834ce02bd3956e956d4',1,'Sifteo::BG0ROMDrawable']]]
];
