var searchData=
[
  ['pinnedassetimage',['PinnedAssetImage',['../struct_sifteo_1_1_pinned_asset_image.html',1,'Sifteo']]]
];
