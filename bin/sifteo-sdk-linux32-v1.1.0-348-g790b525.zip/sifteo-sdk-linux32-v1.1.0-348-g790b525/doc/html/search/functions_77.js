var searchData=
[
  ['width',['width',['../struct_sifteo_1_1_f_b_drawable.html#af83fc27f56780db6b43950084b3ffdc6',1,'Sifteo::FBDrawable::width()'],['../struct_sifteo_1_1_sprite_ref.html#a433126a838a5386991f8c8facca17882',1,'Sifteo::SpriteRef::width()']]],
  ['windowfirstline',['windowFirstLine',['../struct_sifteo_1_1_video_buffer.html#a7f81210128f8f6e21460a0d7c0582681',1,'Sifteo::VideoBuffer']]],
  ['windownumlines',['windowNumLines',['../struct_sifteo_1_1_video_buffer.html#a67c8f736b7cab1d4699a5fda16f02c48',1,'Sifteo::VideoBuffer']]],
  ['write',['write',['../struct_sifteo_1_1_bluetooth_queue.html#a9d32a93d4e6ff9525af54ce86d7a82df',1,'Sifteo::BluetoothQueue::write()'],['../struct_sifteo_1_1_bluetooth_pipe.html#a9948531def82380823d532b5f9d26f66',1,'Sifteo::BluetoothPipe::write()'],['../class_sifteo_1_1_stored_object.html#a041e820e61e67ca90bc8ee225b6060bb',1,'Sifteo::StoredObject::write(const void *data, unsigned dataSize) const '],['../class_sifteo_1_1_stored_object.html#a772401b125e4898f920ee8e76aa5e6cd',1,'Sifteo::StoredObject::write(const T &amp;buffer) const ']]],
  ['writeavailable',['writeAvailable',['../struct_sifteo_1_1_bluetooth_queue.html#a6967fe0d67b4ecd0667e22b885697b24',1,'Sifteo::BluetoothQueue::writeAvailable()'],['../struct_sifteo_1_1_bluetooth_pipe.html#adcea7ee27c20833a654a6ea619da55df',1,'Sifteo::BluetoothPipe::writeAvailable()']]],
  ['writeobject',['writeObject',['../class_sifteo_1_1_stored_object.html#a42b814d79fdd03a479dc0ff4b0d47dba',1,'Sifteo::StoredObject']]]
];
