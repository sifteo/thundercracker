var searchData=
[
  ['receivequeue',['receiveQueue',['../struct_sifteo_1_1_bluetooth_pipe.html#a9d28343e527dee9389ffbc9b583cb43a',1,'Sifteo::BluetoothPipe']]]
];
