var searchData=
[
  ['hardwareversion',['HardwareVersion',['../class_sifteo_1_1_system.html#ab233bd0c35c0bbe8ef1e2fae8dedd9d0',1,'Sifteo::System']]]
];
