-- Metadata

IconAssets = group{quality=9.95}
Icon = image{"icon.png"}
