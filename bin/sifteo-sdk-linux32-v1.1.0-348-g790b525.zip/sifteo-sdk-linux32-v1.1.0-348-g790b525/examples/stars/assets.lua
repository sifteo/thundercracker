IconAssets = group{quality=9.95}
Icon = image{"icon.png"}

Music = tracker{"sv_ttt.xm"}

GameAssets = group{}
Background = image{"stars-bg.png", quality=10}
Star = image{"star-8.png", pinned=true, width=8, height=8}
Font = image{"font-8x16.png", pinned=true, width=8, height=16}
