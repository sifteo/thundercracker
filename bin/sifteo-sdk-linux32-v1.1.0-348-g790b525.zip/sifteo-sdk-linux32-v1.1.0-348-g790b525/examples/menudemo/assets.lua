-- Metadata

IconAssets = group{quality=9.95}
Icon = image{"icon.png"}

-- Menu Assets

BetterflowAssets = group{quality=10}

BgTile = image{ "bg.png", pinned=1 }
StripeTile = image{ "stripes.png", pinned=1 }

IconSandwich = image{ "IconSandwich.png" }
IconChroma = image{ "IconChroma.png" }
IconPeano = image{ "IconPeano.png" }
IconBuddy = image{ "IconBuddy.png"}

Tip0 = image{ "Tip0.png" }
Tip1 = image{ "Tip1.png" }
Tip2 = image{ "Tip2.png" }

Footer = image{ "Footer.png" }

LabelEmpty = image{ "LabelEmpty.png" }
LabelSandwich = image{ "LabelSandwich.png" }
LabelChroma = image{ "LabelChroma.png" }
LabelPeano = image{ "LabelPeano.png" }
LabelBuddy = image{ "LabelBuddy.png"}
