var searchData=
[
  ['value',['value',['../struct_sifteo_1_1_r_g_b565.html#aab28724ae443519720a500a30bc06e34',1,'Sifteo::RGB565']]],
  ['volumecommit',['volumeCommit',['../namespace_sifteo_1_1_events.html#a9a7c75db7acade727b784040b012061e',1,'Sifteo::Events']]],
  ['volumedelete',['volumeDelete',['../namespace_sifteo_1_1_events.html#a92bfd19cdd0b0976841887a8885acf01',1,'Sifteo::Events']]]
];
