var searchData=
[
  ['undef_5floop',['UNDEF_LOOP',['../struct_sifteo_1_1_audio_channel.html#a2dccc94619b8f5f1aa1ee76868a788a0a3e4a76804c5310af8cdbbc501b725510',1,'Sifteo::AudioChannel']]]
];
