var searchData=
[
  ['undefined',['UNDEFINED',['../struct_sifteo_1_1_audio_channel.html#add25e560eadc585a0cb132025a08e1d7',1,'Sifteo::AudioChannel::UNDEFINED()'],['../struct_sifteo_1_1_cube_i_d.html#ac9ab1ce1985b9cc8adf58912ce805fce',1,'Sifteo::CubeID::UNDEFINED()']]]
];
