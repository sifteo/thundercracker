var searchData=
[
  ['gamemenueventvector',['GameMenuEventVector',['../struct_sifteo_1_1_game_menu_event_vector.html',1,'Sifteo']]]
];
