var searchData=
[
  ['no_5fside',['NO_SIDE',['../group__cube.html#gga8dc17340f515227e9bb34532bfc2fef3a907c90c21486c90c851379c9dd79b1b8',1,'Sifteo']]],
  ['num_5fsides',['NUM_SIDES',['../group__cube.html#gga8dc17340f515227e9bb34532bfc2fef3acfd3767ac3e69432b6a0bd7106c35f4e',1,'Sifteo']]]
];
