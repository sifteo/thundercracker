var searchData=
[
  ['umod',['umod',['../group__math.html#gacd70c1d896652ae6cd08793202b929bf',1,'Sifteo']]],
  ['uniform',['uniform',['../struct_sifteo_1_1_random.html#a1af06331806ac52b38fb9c9a79c0271d',1,'Sifteo::Random']]],
  ['unit',['unit',['../struct_sifteo_1_1_vector2.html#a0eb0713d12c56bffdbbdb8d896a586d1',1,'Sifteo::Vector2']]],
  ['unlock',['unlock',['../struct_sifteo_1_1_video_buffer.html#a5b6ffc064efbf5e7f9c55bb60698c2df',1,'Sifteo::VideoBuffer']]],
  ['unpair',['unpair',['../struct_sifteo_1_1_cube_i_d.html#a327a4939945b52a6756ab9f2b801ba86',1,'Sifteo::CubeID']]],
  ['unset',['unset',['../struct_sifteo_1_1_event_vector.html#a2929708f992ccd44af7ee5941bdd0940',1,'Sifteo::EventVector::unset()'],['../struct_sifteo_1_1_nullary_event_vector.html#ac8d47e09c595824f8595dcc69dbfc9f2',1,'Sifteo::NullaryEventVector::unset()'],['../struct_sifteo_1_1_game_menu_event_vector.html#abdc720ab07e1238d16428db82b068974',1,'Sifteo::GameMenuEventVector::unset()'],['../struct_sifteo_1_1_neighbor_event_vector.html#a9a20d1e55414d0ccc3df4a1739bb919f',1,'Sifteo::NeighborEventVector::unset()']]],
  ['update',['update',['../class_sifteo_1_1_tilt_shake_recognizer.html#adb652e01d5b155997bb916224f363992',1,'Sifteo::TiltShakeRecognizer']]],
  ['uptime',['uptime',['../class_sifteo_1_1_system_time.html#a5bdbc1d315eab51d972892b83caab202',1,'Sifteo::SystemTime']]],
  ['uptimems',['uptimeMS',['../class_sifteo_1_1_system_time.html#a8d1e2d1b99fdcfa4e8feff975bee44b5',1,'Sifteo::SystemTime']]],
  ['uptimens',['uptimeNS',['../class_sifteo_1_1_system_time.html#ad7d61048b246377a6f89b436cce3f4f4',1,'Sifteo::SystemTime']]],
  ['uptimeus',['uptimeUS',['../class_sifteo_1_1_system_time.html#ad5a99a59881d5f740bb9378fa20606b9',1,'Sifteo::SystemTime']]],
  ['userpacketsdropped',['userPacketsDropped',['../struct_sifteo_1_1_bluetooth_counters.html#ae32bfd8fbd8f0a070dccad062a17b229',1,'Sifteo::BluetoothCounters']]],
  ['uuid',['uuid',['../class_sifteo_1_1_mapped_volume.html#a900fb37198d6a7d3b7248b606ff7ae3f',1,'Sifteo::MappedVolume']]]
];
