var searchData=
[
  ['tick_5fhz',['TICK_HZ',['../struct_sifteo_1_1_motion_buffer.html#a3c6c96116960f2d30e71db772c528ded',1,'Sifteo::MotionBuffer::TICK_HZ()'],['../class_sifteo_1_1_motion_iterator.html#a93e83ec89228d149dcb407bd25c9f5eb',1,'Sifteo::MotionIterator::TICK_HZ()']]],
  ['tick_5fns',['TICK_NS',['../struct_sifteo_1_1_motion_buffer.html#a03dcaddd84e862d6eb134ec6940deadd',1,'Sifteo::MotionBuffer::TICK_NS()'],['../class_sifteo_1_1_motion_iterator.html#a5aaf945e7904fc4914c1b6bd82aa8f70',1,'Sifteo::MotionIterator::TICK_NS()']]],
  ['tick_5fus',['TICK_US',['../struct_sifteo_1_1_motion_buffer.html#a8b5fb69f39bb685c573c19316b39f9ab',1,'Sifteo::MotionBuffer::TICK_US()'],['../class_sifteo_1_1_motion_iterator.html#ac777f2c43b6f36d8c888dcc18d213e45',1,'Sifteo::MotionIterator::TICK_US()']]],
  ['tilt',['tilt',['../class_sifteo_1_1_tilt_shake_recognizer.html#a4c97f21b06aee37eb349fd788461ca58',1,'Sifteo::TiltShakeRecognizer']]]
];
